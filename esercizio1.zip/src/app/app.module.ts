import { Route, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './pages/home/home.component';
import { ActivePostsComponent } from './pages/active-posts/active-posts.component';
import { InactivePostsComponent } from './pages/inactive-posts/inactive-posts.component';
import { NavbarComponent } from './pages/navbar/navbar.component';
import { PostCardComponent } from './pages/post-card/post-card.component';
import { UsersComponent } from './pages/users/users.component';
import { UsersService } from './users.service';
import { UsersDetailsComponent } from './pages/users-details/users-details.component';
import { PostDetailsComponent } from './pages/post-details/post-details.component';

const routes: Route[] = [
  {
    path:'',
    component: HomeComponent,
  },
  {
    path:'active-posts',
    component: ActivePostsComponent,
  },
  {
    path:'inactive-posts',
    component:InactivePostsComponent,
  },
  {
    path:'active-posts/:id',
    component:PostDetailsComponent,
  },
  {
    path:'inactive-posts/:id',
    component:PostDetailsComponent,
  },
  {
    path:'users',
    component: UsersComponent,
    children:
    [
    {
      path:':id',
      component: UsersDetailsComponent
    }
    ]
  }
]

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ActivePostsComponent,
    InactivePostsComponent,
    NavbarComponent,
    PostCardComponent,
    UsersComponent,
    UsersDetailsComponent,
    PostDetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(routes),
  ],
  providers: [UsersService],
  bootstrap: [AppComponent]
})
export class AppModule { }
