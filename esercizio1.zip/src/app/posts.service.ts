import { Post } from "./models/post";

let posts: Post[] = [
  {
    id: 1,
    title: 'Primo post',
    body: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis odit consectetur dignissimos itaque enim nesciunt illo, quas similique sunt, atque animi tempore rerum, repellendus repudiandae saepe. Aliquam vitae possimus autem?',
    active: false,
    type: 'news',
    author: 'Dario',
  },
  {
    id: 2,
    title: 'Secondo post',
    body: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis odit consectetur dignissimos itaque enim nesciunt illo, quas similique sunt, atque animi tempore rerum, repellendus repudiandae saepe. Aliquam vitae possimus autem?',
    active: true,
    type: 'politic',
    author: 'Francesco'
  },
  {
    id: 3,
    title: 'Terzo post',
    body: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis odit consectetur dignissimos itaque enim nesciunt illo, quas similique sunt, atque animi tempore rerum, repellendus repudiandae saepe. Aliquam vitae possimus autem?',
    active: false,
    type: 'education',
    author:'Giovanni'
  },
  {
    id: 4,
    title: 'Quarto post',
    body: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis odit consectetur dignissimos itaque enim nesciunt illo, quas similique sunt, atque animi tempore rerum, repellendus repudiandae saepe. Aliquam vitae possimus autem?',
    active: true,
    type: 'politic',
    author:'Thomas'
  },
  {
    id: 5,
    title: 'Quinto post',
    body: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis odit consectetur dignissimos itaque enim nesciunt illo, quas similique sunt, atque animi tempore rerum, repellendus repudiandae saepe. Aliquam vitae possimus autem?',
    active: false,
    type: 'education',
    author: 'Davide'
  },
];

export function getPosts(){
  return posts;
}

export function updatePosts(data: Partial<Post>, id: number){
  posts = posts.map(post => post.id == id? {...post, ...data} : post);
  return posts.find(post => post.id == id) as Post;
}
